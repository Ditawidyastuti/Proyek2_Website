-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 23 Mei 2017 pada 04.53
-- Versi Server: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_proyek`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id_admin` int(10) NOT NULL,
  `username_admin` varchar(10) NOT NULL,
  `password_admin` varchar(10) NOT NULL,
  `alamat_admin` varchar(30) NOT NULL,
  `email_admin` varchar(30) NOT NULL,
  `telp_admin` varchar(20) NOT NULL,
  `level_admin` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_admin`
--

INSERT INTO `tb_admin` (`id_admin`, `username_admin`, `password_admin`, `alamat_admin`, `email_admin`, `telp_admin`, `level_admin`) VALUES
(1, 'kokom', 'admin', 'Kebonagung', 'qomariyah2211@gmail.com', '085741908343', 'Super Admin'),
(6, 'dita', 'admin', 'Sragi', 'ditawidyas@gmail.com', '087865123009', 'Admin'),
(7, 'adit', 'admin', 'Kedungwuni', 'adytama@gmail.com', '0857442856087', 'Admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_inbox`
--

CREATE TABLE `tb_inbox` (
  `id_inbox` int(12) NOT NULL,
  `nama_inbox` varchar(15) NOT NULL,
  `email_inbox` varchar(30) NOT NULL,
  `pesan` varchar(140) NOT NULL,
  `tgl_pesan` date NOT NULL,
  `sudahbaca` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_inbox`
--

INSERT INTO `tb_inbox` (`id_inbox`, `nama_inbox`, `email_inbox`, `pesan`, `tgl_pesan`, `sudahbaca`) VALUES
(3, 'Shofia Nabila', 'shofia.nabila@gmail.com', 'Wow, disini banyak sekali produk yang bagus tapi sayangnya harganya terlalu mahal. :D', '2017-05-06', 'Y'),
(4, 'Miftahul', 'mifathulilmi@gmail.com', 'website yang sangat keren', '2017-05-06', 'Y'),
(8, 'Rika F', 'rikafadillah@gmail.com', 'sangat keren, ini bisa dijadikan sebuah ide untuk membuka peluang usaha baru yang penuh dengan kreativitas', '2017-05-07', 'Y'),
(9, 'Budi', 'inibudi@gmail.com', 'ini adalah pesan dari budi.', '2017-05-08', 'Y'),
(10, 'Asifah Ulul', 'asifah.ulu@gmail.com', 'ini pesan dari asifah', '2017-05-09', 'Y'),
(11, 'Saputra', 'aditama@gmail.com', 'ini adalah pesan dari adit', '2017-05-10', 'Y'),
(12, 'Yuga Virgian', 'yugavirgian@yahoo.com', 'ini adalah pesan dari yuga imut :p', '2017-05-12', 'Y'),
(16, 'Ayumi', 'ayumiii@gmail.com', 'hai kakak', '2017-05-14', 'Y'),
(17, 'Dewi', 'dewidewi@gmail.com', 'bagus sekali', '2017-05-16', 'N'),
(18, 'dita.w', 'dita@gmail.com', 'kerajinannya bagus-bagus...', '2017-05-17', 'N'),
(19, 'muhammad saputr', 'wongmacul@gmail.com', 'macul kang nangsawah saiki :D', '2017-05-17', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_member`
--

CREATE TABLE `tb_member` (
  `id_member` int(10) NOT NULL,
  `nama_member` varchar(30) NOT NULL,
  `email_member` varchar(30) NOT NULL,
  `password_member` varchar(20) NOT NULL,
  `alamat_member` varchar(50) NOT NULL,
  `kode_pos` varchar(10) NOT NULL,
  `telp_member` varchar(15) NOT NULL,
  `tgl_member` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_member`
--

INSERT INTO `tb_member` (`id_member`, `nama_member`, `email_member`, `password_member`, `alamat_member`, `kode_pos`, `telp_member`, `tgl_member`) VALUES
(1, 'Amalia Fadillah', 'amaliaaa@gmail.com', 'amalia', 'Kebonagung, Kajen, Pekalongan', '51161', '085741988732', '2017-05-07'),
(2, 'Shofia', 'shofia.nabila@gmail.com', 'shofinabila', 'Mekaragung, Kebonagung, Kajen, Pekalongan', '51161', '028133885985', '2017-05-07'),
(4, 'Jonathan', 'jojo@gmail.com', 'jojojojo', 'Paesan Utara, Kedungwuni', '51189', '083256751907', '2017-05-07'),
(5, 'Sakti', 'msakti@gmail.com', 'sakti', 'Paesan Utara, Kedungwuni', '51189', '08765412903', '2017-05-07'),
(6, 'Salsa', 'sasaaa@gmail.com', 'salsa', 'Mekaragung, Kebonagung, Kajen, Pekalongan', '51161', '086428571889', '2017-05-07'),
(7, 'Risky', 'kykyrisky@gmail.com', 'kiki', 'Karangsari, Karanganyar', '51161', '086456789235', '2017-05-07'),
(8, 'Anas', 'anasfitri@gmail.com', 'pipipit', 'Karangsari, Karanganyar', '51160', '085431790022', '2017-05-07'),
(9, 'Asifah', 'asifahulul@gmail.com', 'asifahulul', 'Perum GSM Kebonagung, Blok A No.32', '51161', '085743163766', '2017-05-07'),
(10, 'Novelia', 'novelia@gmail.com', 'novelia', 'Bababalan, Bojong', '51163', '08754342222', '2017-05-07'),
(11, 'ojo kepo aku anonymous', 'anonymous@gmail.com', 'anonymous.com', '192.168.1.1', '51173', '08999799146', '2017-05-17');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_order`
--

CREATE TABLE `tb_order` (
  `id_order` int(12) NOT NULL,
  `id_member` int(12) NOT NULL,
  `id_produk` int(12) NOT NULL,
  `tgl_order` date NOT NULL,
  `jumlah_order` int(11) NOT NULL,
  `harga_total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_produk`
--

CREATE TABLE `tb_produk` (
  `id_produk` int(12) NOT NULL,
  `nama_produk` varchar(50) NOT NULL,
  `harga_produk` bigint(20) NOT NULL,
  `kategori_produk` varchar(12) NOT NULL,
  `stok` int(11) NOT NULL,
  `gbr_produk` varchar(50) NOT NULL,
  `desc_produk` varchar(500) NOT NULL,
  `tgl_produk` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_produk`
--

INSERT INTO `tb_produk` (`id_produk`, `nama_produk`, `harga_produk`, `kategori_produk`, `stok`, `gbr_produk`, `desc_produk`, `tgl_produk`) VALUES
(24, 'Lampu 1', 250000, 'Kaca', 4, 'Lampu1.jpg', 'Produk ini mempunyai keunggulan baik dari desain maupun materialnya sehingga dijamin akan memuaskan anda yang akan membeli produk ini. Mempunyai daya sebesar 5 watt pada setiap satu lampunya sehingga cocok untuk lampu hias. Terdiri dari 6 botol bermaterial kaca sehingga sangat cocok untuk menghiasi ruang tamu atau keluarga di rumah anda.', '2017-05-08'),
(25, 'Lampu 2', 475000, 'Kaca', 5, 'Lampu2.jpg', 'Lampu ini terdiri dari 5 botol kaca yang berwarna-warni. Mempunyai daya sebesar 5 watt pada setiap lampunya.', '2017-05-08'),
(26, 'Lampu3', 250000, 'Kaca', 6, 'Lampu3.jpg', 'Lampu hias ini terbuat dari botol kaca bekas, dan sangat cocok jika ditempatkan di ruang tamu.', '2017-05-09'),
(27, 'Lampu4', 300000, 'Kaca', 3, 'Lampu4.jpg', 'Tebuat dari botol bekas dan cocok untuk ditempatkan di ruang tamu karena bentuknya yang sangat unik.', '2017-05-09'),
(28, 'Lampu 5', 150000, 'Kaca', 2, 'Lampu5.jpg', 'Lampu hias yang terbuat dari botol kaca dan cocok untuk ditempatkan di ruang tamu maupun ruang keluarga.', '2017-05-09'),
(29, 'Lampu 6', 150000, 'Kaca', 4, 'Lampu6.jpg', 'Lampu gantung ini cocok untuk ditempatkan di ruang keluarga bahkan bisa ditempatkan di ruang tamu.', '2017-05-09'),
(30, 'Lampu 7', 210000, 'Plastik', 5, 'Lampu7.jpg', 'Terbuat dari botol plastik bekas dan berbentuk bunga sehingga semakin membuat lampu hias ini menjadi semakin unik.', '2017-05-09'),
(31, 'Lampu 8', 150000, 'Kaca', 8, 'Lampu8.jpg', 'Terbuat dari botol bekas kaca dan cocok ditempatkan di semua ruangan.', '2017-05-09'),
(32, 'Lampu 9', 200000, 'Kaca', 3, 'Lampu9.jpg', 'Terbuat dari botol bekas yang cocok untuk ditempatkan di semua ruangan.', '2017-05-09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `tb_inbox`
--
ALTER TABLE `tb_inbox`
  ADD PRIMARY KEY (`id_inbox`);

--
-- Indexes for table `tb_member`
--
ALTER TABLE `tb_member`
  ADD PRIMARY KEY (`id_member`);

--
-- Indexes for table `tb_order`
--
ALTER TABLE `tb_order`
  ADD PRIMARY KEY (`id_order`),
  ADD KEY `id_member` (`id_member`),
  ADD KEY `id_produk` (`id_produk`);

--
-- Indexes for table `tb_produk`
--
ALTER TABLE `tb_produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id_admin` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tb_inbox`
--
ALTER TABLE `tb_inbox`
  MODIFY `id_inbox` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `tb_member`
--
ALTER TABLE `tb_member`
  MODIFY `id_member` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tb_order`
--
ALTER TABLE `tb_order`
  MODIFY `id_order` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tb_produk`
--
ALTER TABLE `tb_produk`
  MODIFY `id_produk` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tb_order`
--
ALTER TABLE `tb_order`
  ADD CONSTRAINT `tb_order_ibfk_1` FOREIGN KEY (`id_member`) REFERENCES `tb_member` (`id_member`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tb_order_ibfk_2` FOREIGN KEY (`id_produk`) REFERENCES `tb_produk` (`id_produk`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
